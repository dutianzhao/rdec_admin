
/**
 *
 * Convenience classes for using Spring's AOP API.
 *
 */
package org.springframework.aop.support;

